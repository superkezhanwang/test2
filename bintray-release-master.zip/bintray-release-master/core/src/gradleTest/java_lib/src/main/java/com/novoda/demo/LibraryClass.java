package com.novoda.demo;

public class LibraryClass {

}
