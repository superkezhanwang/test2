package com.novoda.gradle.test

public interface IntegrationTest {
}
